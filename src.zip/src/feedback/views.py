from django.shortcuts import render
from django.views.generic import CreateView
# Create your views here.
from .models import FeedbackW
from .forms import FeedbackWForm
class FeedbackWView(CreateView):
    form_class = FeedbackWForm
    success_url = '/success/'
    template_name ="Feedback_form.html"
    def form_valid(self, form):
        lesson = form.save(commit=False)
        lesson.user=self.request.user
        lesson.save()
        return super(FeedbackWView, self).form_valid(form)
        