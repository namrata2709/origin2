from django.apps import AppConfig


class FeedbackConfig(AppConfig):
    name = 'feedback'
