from django import forms
from .models import FeedbackW

class FeedbackWForm(forms.ModelForm):
	class Meta:
		model = FeedbackW
		fields = ['Comments']
		widgets = {
			'Comments':forms.Textarea(attrs={'cols': 80, 'rows': 15,'placeholder':'Your comments...','id':"message",'class':"input100",'name':"message"},),
        }