from django.urls import path

from .views import FeedbackWView

urlpatterns = [
   
   path('',FeedbackWView.as_view(),name='feedback'),
   
]