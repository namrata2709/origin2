from django.shortcuts import render
from django.views.generic import ListView,DetailView,View,CreateView,DeleteView,UpdateView
from django.urls import reverse_lazy

from .models import Course,Lesson,Comment
from .forms import CoursesForm,LessonsForm,CommentForm

from starttest.models import Topic
from userdetails.models import Student_detail

class CourseDetailView(DetailView):
	model=Course
	template_name="course_detail.html"

class LessonDetailView(DetailView):
	model=Lesson
	template_name="lesson_detail.html"

class CourseListView(ListView):
	model=Course
	context_object_name = 'courses'
	template_name="course_list.html"

class CourseAdd(CreateView):
    form_class = CoursesForm
    success_url = reverse_lazy('CourseListView')
    template_name ="Course_form.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(CourseAdd, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    

class LessonAdd(CreateView):
    form_class = LessonsForm
    success_url = reverse_lazy('CourseDetailView')
    template_name ="Lesson_form.html"
    def get_context_data(self,**kwargs):
        kwargs=super(LessonAdd,self).get_context_data(**kwargs)
        kwargs['pk']=self.kwargs.get('pk')
        return kwargs
    def form_valid(self, form):
        lesson = form.save(commit=False)
        lesson.Course=Course.objects.get(id=self.kwargs['pk'])
        lesson.save()
        return super(LessonAdd, self).form_valid(form)
        
class LessonUpdate(UpdateView):
    model =Lesson
    template_name ="Lesson_form.html"
    form_class = LessonsForm
    success_url = reverse_lazy('CourseDetailView')
class LessonDelete(DeleteView):
    model = Lesson
    template_name ="Lesson_confirm_delete.html"
    success_url = reverse_lazy('CourseDetailView')


class CourseUpdate(UpdateView):
    model =Course
    template_name ="Course_form.html"
    form_class = CoursesForm
    success_url = reverse_lazy('CourseListView')
    def get_form_kwargs(self, **kwargs):
        kwargs = super(CourseUpdate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs
    
class CourseDelete(DeleteView):
    model = Course
    template_name ="Course_confirm_delete.html"
    success_url = reverse_lazy('CourseListView')

class StudentBridgeCourse(View):
    form_class = CommentForm
    initial = {'key': 'value'}
    template_name = 'BrigdeCourse.html'
    def get(self, request, *args, **kwargs):
        course=Course.objects.get(id=kwargs['course_id'])
        lesson=course.lessons.get(id=kwargs['lesson_id'])
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form , 'course' :course , 'lesson' : lesson })

    def post(self, request, *args, **kwargs):
        course=Course.objects.get(id=kwargs['course_id'])
        lesson=course.lessons.get(id=kwargs['lesson_id'])
        form = self.form_class(request.POST)
        if form.is_valid():   
            comment=Comment.objects.create(comment=form.cleaned_data['comment'])
            comment.Course=course
            comment.user=Student_detail.objects.get(email_id=request.user)
            comment.save()
        return render(request, self.template_name, {'form': form, 'course' :course , 'lesson' : lesson })

