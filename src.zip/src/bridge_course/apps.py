from django.apps import AppConfig


class BridgeCourseConfig(AppConfig):
    name = 'bridge_course'
