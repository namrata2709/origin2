from django import forms

from embed_video.fields import EmbedVideoFormField

from starttest.models import Topic
from userdetails.models import Teacher_detail

from .models import Course,Lesson,Comment
class CoursesForm(forms.ModelForm):
	class Meta:
		model = Course
		fields = ['title','description','Topic','days']
	def __init__(self, user, *args, **kwargs):
	 	super(CoursesForm, self).__init__(*args, **kwargs)
	 	self.fields['Topic'].queryset =Topic.objects.filter(teacher__in=Teacher_detail.objects.filter(email_id=user))

class LessonsForm(forms.ModelForm):
	class Meta:
		model = Lesson
		fields=['title','position','thumbnail','video']

class CommentForm(forms.ModelForm):
	class Meta:
		model = Comment
		fields=['comment']
		widgets = {
			'comment':forms.Textarea(attrs={'cols':20, 'rows': 1,'placeholder':'Your comments...','id':"message",'class':"input100",'name':"message"},),
        }

		
