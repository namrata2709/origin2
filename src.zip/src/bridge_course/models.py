from django.db import models
from starttest.models import Topic
from embed_video.fields import EmbedVideoField
from userdetails.models import Student_detail
# Create your models here.
def upload_location(instance):
	return "%s"%(instance.id)
class Lesson(models.Model):
	title=models.CharField(max_length=120)
	Course=models.ForeignKey(
        'Course',
        on_delete=models.CASCADE,
        null=True
        )
	position=models.IntegerField()
	video=EmbedVideoField()
	thumbnail=models.ImageField(
					upload_to="upload_location",
					null=True,blank=True,
					width_field="width_field",
					height_field="height_field"
					)
	height_field=models.IntegerField(default=10)
	width_field=models.IntegerField(default=10)

class Course(models.Model):
	title=models.CharField(max_length=120)
	description=models.CharField(max_length=250)
	user=models.ManyToManyField(Student_detail)
	Topic=models.ForeignKey(
        'starttest.Topic',
        on_delete=models.CASCADE,
        )
	days=models.IntegerField()
	@property
	def lessons(self):
		return self.lesson_set.all().order_by('position')
	@property
	def comments(self):
		return self.comment_set.all().order_by('-id')
	

class Comment(models.Model):
	comment=models.CharField(max_length=150)
	Course=models.ForeignKey(
        'Course',
        on_delete=models.CASCADE,
        null=True
        )
	user=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True
        )