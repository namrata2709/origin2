from django.urls import path

from .views import CourseDetailView,LessonDetailView,CourseListView,CourseAdd,CourseUpdate,CourseDelete,LessonAdd,LessonUpdate,LessonDelete,StudentBridgeCourse

urlpatterns = [
   path('detail/<int:pk>',CourseDetailView.as_view(),name='CourseDetailView'),
   path('',CourseListView.as_view(),name='CourseListView'),
   path('add/',CourseAdd.as_view(),name='CourseAdd'),
   path('update/<int:pk>',CourseUpdate.as_view(),name='CourseUpdate'),
   path('delete/<int:pk>',CourseDelete.as_view(),name='CourseDelete'),
   path('lesson/<int:pk>',LessonDetailView.as_view(),name='LessonDetailView'),
   path('lesson/add/<int:pk>',LessonAdd.as_view(),name='LessonAdd'),
   path('lesson/update/<int:pk>',LessonUpdate.as_view(),name='LessonUpdate'),
   path('lesson/delete/<int:pk>',LessonDelete.as_view(),name='LessonDelete'),
   path('student/bridge/<int:course_id>/<int:lesson_id>',StudentBridgeCourse.as_view(),name='StudentBridgeCourse'),
]