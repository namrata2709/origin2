from django import forms


from .models import Assignment_question,assignment_submission

from userdetails.models import Teacher_detail 
from subject.models import Subject
# Create your views here.
class Assignmentadd(forms.ModelForm):
	
	class Meta:
		model = Assignment_question
		fields =('Assignment_name','Assignment_details','document','subject_name','day')
		widgets = {
			'Assignment_name':forms.TextInput(attrs={'class':"input200" ,'placeholder':"Enter assignment name"},),
			'Assignment_details':forms.TextInput(attrs={'class':"input200" ,'placeholder':"Enter assignment details"},),
			'document':forms.FileInput(),
			'subject_name':forms.Select(attrs={'class':"selection-2" ,},),
			'day':forms.NumberInput(attrs={'class':"input200" ,'placeholder':"Enter the no. of days in which assignment should be completed"},)
        }
	def __init__(self, user, *args, **kwargs):
	 	super(Assignmentadd, self).__init__(*args, **kwargs)
	 	self.fields['subject_name'].queryset = Subject.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name'))


class SubmitAssignment(forms.ModelForm):
	class  Meta:
		model=assignment_submission
		fields=['document']
		widgets = {
			'document':forms.FileInput(attrs={'class':"btn btn-sn"}),
        }
			