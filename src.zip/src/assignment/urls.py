from django.urls import path

from .views import (
					AssignmentCreate,
					AssignmentUpdate,
					AssignmentDelete,
					AssignmentDetailView,
					AssignmentListView,
					assignmentdownload,
					Student_Assignment_detail,
					AssignmentApproveView,
					AssignmentDisapprove,
					AssignmentApprove
					)

urlpatterns = [
   path('detail/<int:pk>',AssignmentDetailView.as_view(),name='AssignmentDetailView'),
   path('',AssignmentListView.as_view(),name='AssignmentListView'),
   path('add/',AssignmentCreate.as_view(),name='AssignmentAdd'),
   path('update/<int:pk>',AssignmentUpdate.as_view(),name='AssignmentUpdate'),
   path('delete/<int:pk>',AssignmentDelete.as_view(),name='AssignmentDelete'),
   path('student/<int:assign_id>',Student_Assignment_detail.as_view(),name='Student_Assignment_detail'),
   path('download/<int:id>', assignmentdownload,name='assignmentdownload'),
   path('disapprove/<int:id>/', AssignmentDisapprove, name='AssignmentDisapprove'),
   path('approve/<int:id>/', AssignmentApprove, name='AssignmentApprove'),
   path('approveview/',AssignmentApproveView.as_view(),name='AssignmentApproveView'),

]