from django.shortcuts import render
from django.views import generic
from django.http import HttpResponse,HttpResponseRedirect #used for download
from django.conf import settings #used for download
from django.views.generic import ListView,DetailView,View,CreateView,DeleteView,UpdateView,TemplateView
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.core.mail import send_mail
from django.template.loader import render_to_string

import os#used for download

from userdetails.models import Teacher_detail,Student_detail
from task_assign.models import Tasks

from .models import Assignment_question,assignment_submission,assignment_student
from .forms import Assignmentadd,SubmitAssignment


def assignmentdownload(request, id):
    path=Assignment_question.objects.get(pk=id) 
    obj=str(path.document)
    file_path = os.path.join(settings.MEDIA_ROOT, obj)
    if os.path.exists(file_path):
        #return  HttpResponse(path)
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/zip")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404
    return  HttpResponse(path)


class AssignmentCreate(CreateView):
    model =Assignment_question
    form_class = Assignmentadd
    success_url = reverse_lazy('AssignmentListView')
    template_name ="Assignment_add.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(AssignmentCreate,self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    def form_valid(self, form):
        Assignment = form.save(commit=False)
        Assignment.teacher_id=Teacher_detail.objects.get(email_id=self.request.user)
        Assignment.save()
        return super(AssignmentCreate, self).form_valid(form)
class AssignmentUpdate(UpdateView):
    model =Assignment_question
    template_name ="Assignment_add.html"
    form_class = Assignmentadd
    success_url = reverse_lazy('AssignmentListView')
    def get_form_kwargs(self, **kwargs):
        kwargs = super(AssignmentUpdate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    def form_valid(self, form):
        #try:
        Assignment = form.save(commit=False)
        Assignment.teacher_id=Teacher_detail.objects.get(email_id=self.request.user)
        Assignment.save()
        return super(AssignmentUpdate, self).form_valid(form)
class AssignmentDelete(DeleteView):
    model = Assignment_question
    template_name ="Assignment_confirm_delete.html"
    success_url = reverse_lazy('AssignmentListView')

class AssignmentDetailView(DetailView):
	model=Assignment_question
	template_name="Assignment_detail.html"

class AssignmentListView(ListView):
	model=Assignment_question
	context_object_name = 'Assignment'
	template_name="Assignment_list.html"



class Student_Assignment_detail(View):
    form_class = SubmitAssignment
    model=assignment_submission
    initial = {'key': 'value'}
    template_name = 'student_Assignment.html'
    def get(self, request, *args, **kwargs):
        assign=Assignment_question.objects.get(pk=kwargs['assign_id'])
        submit='false'
        if assignment_submission.objects.filter(assigment_id=assign,disapprove=False).exists() :
            submit='already'
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form , 'assign' :assign,'submit':submit })

    def post(self, request, *args, **kwargs):

        assign=Assignment_question.objects.get(pk=kwargs['assign_id'])
        form = self.form_class(request.POST, request.FILES)
        if form.is_valid():   
            asssub=assignment_submission.objects.create(document=form.cleaned_data['document'])
            asssub.assigment_id=assign
            asssub.Stud_id=Student_detail.objects.get(email_id=self.request.user)
            asssub.save()
            user=assign.teacher_id.email_id
            from_email=settings.DEFAULT_FROM_EMAIL
            subject='An new assignment has been submitted by ' +asssub.Stud_id.email_id.email +'\nPlease approve or disapprove it '
            mail_subject = 'new Assignment '
            message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
            to_email = [user.email]
            send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
        return HttpResponseRedirect(reverse_lazy('Student_Assignment_detail',kwargs={'assign_id':self.kwargs['assign_id']}))

class AssignmentApproveView(TemplateView):
    template_name="AssignmentApprove.html"
    def get_context_data(self,*args,**kwargs):
        if Teacher_detail.objects.filter(email_id=self.request.user):
            assign=Assignment_question.objects.filter(teacher_id__email_id=self.request.user)
            context={}
            objects=assignment_submission.objects.filter(document=None)
            for x in assign:
                objects=objects | assignment_submission.objects.filter(assigment_id=x)

            context={"obj":objects}
            return context
def AssignmentDisapprove(request,id):
    
    obj=assignment_submission.objects.get(pk=id ) 
    user=obj.Stud_id.email_id
    obj.disapprove=True
    from_email=settings.DEFAULT_FROM_EMAIL
    subject='Your assignment has been disapproved \n Assignment name ' +obj.assigment_id.Assignment_name +'\nplease submit it again'
    mail_subject = 'Assignment status'
    message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
    to_email = [user.email]
    send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
    obj.save()
    return HttpResponseRedirect(reverse_lazy('AssignmentApproveView'))
def AssignmentApprove(request,id):
    obj=assignment_submission.objects.get(pk=id ) 
    user=obj.Stud_id.email_id
    obj.approve=True
    obj.save()
    from_email=settings.DEFAULT_FROM_EMAIL
    subject='Your assignment has been approved \n Assignment name ' +obj.assigment_id.Assignment_name +'\nThank You'
    mail_subject = 'Assignment status'
    message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
    to_email = [user.email]
    send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
    obj1=assignment_student.objects.get(assigment_id=id)
    obj1.status=True
    obj1.save()
    print(obj.assigment_id.pk)
    obj2=Tasks.objects.get(Teacher_assigned=Teacher_detail.objects.get(email_id=request.user),Types='Assignment',task_id=obj1.pk,stud_id=obj1.Stud_id)
    obj2.Status=True
    obj2.save()
    return HttpResponseRedirect(reverse_lazy('AssignmentApproveView'))
