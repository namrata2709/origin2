from django.contrib import admin

# Register your models here.
from .models import Assignment_question,assignment_student,assignment_submission#,assignment_review
# Register your models here.

admin.site.register(Assignment_question)
#admin.site.register(assignment_review)
admin.site.register(assignment_submission)
admin.site.register(assignment_student)