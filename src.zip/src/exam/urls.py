from django.urls import path

from .views import (
					Question_paper_Main,
					Assign,
					Remedial,
					ExtraPractice,
					Report,
					Question_download,
					Report_download
					)

urlpatterns = [

    path('',Question_paper_Main.as_view(),name='test'),
    path('assign/',Assign.as_view(),name='assign'),
    path('Remedial/',Remedial.as_view(),name='Remedial'),
    path('ExtraPractice/',Remedial.as_view(),name='ExtraPractice'),
    path('Report/',Report.as_view(),name='Report'),
    path('report/<int:Qset_id>',Report_download,name='report'),
    path('download/<int:Qset_id>',Question_download,name='Question_download'),
    
]