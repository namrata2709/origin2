from django.db import models
from question.models import Question
from userdetails.models import Teacher_detail,Student_detail
from django.contrib.postgres.fields import HStoreField
class QuestionSetMain(models.Model):
	Question_number=models.CharField(max_length=10,null=True)
	Question=models.ManyToManyField(
        			'question.Question'
   					 )
	total_marks=models.IntegerField(null=True)
	time=models.IntegerField(null=True)
	student_id=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True
        )
		
class MarksMain(models.Model):
	student_id=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True,
        )
	marks=HStoreField(null=True)
	Qset=models.ForeignKey(
        'QuestionSetMain',
        on_delete=models.CASCADE,
        )
	Date=models.DateField(auto_now=False, auto_now_add=True)