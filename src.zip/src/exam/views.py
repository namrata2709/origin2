from django.shortcuts import render
from django.http import HttpResponseRedirect,HttpResponse
from django.views.generic import CreateView,ListView,DetailView,UpdateView,DeleteView
from django.views import View
from django.urls import reverse_lazy
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.templatetags.static import static

from random import shuffle
from datetime import timedelta 
import math
import datetime
import reportlab
import io 
from io import BytesIO
from django.http import FileResponse
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
import os.path

from userdetails.models import Teacher_detail,Student_detail,UserProfile
from subject.models import Subject
from question.models import Question
from task_assign.models import Progress,Tasks
from assignment.models import Assignment_question,assignment_student
from remediallecture.models import RemedialCourse
from extrapractice.models import ExtraPratice_question,ExtraPratice_student

from .models import QuestionSetMain,MarksMain

def question_array_main(id):
    easy_count=0
    hard_count=0
    medium_count=0
    question_list=[]
    questions_list=[]
    total=0
    time=0
    count=0
    semester=Student_detail.objects.filter(email_id=id).values('semester')
    subject_list=Subject.objects.filter(semester__in=semester,subject_type='theory').values('subject_name')
    for  subject in subject_list:
        q=Question.objects.filter(subject_name__subject_name=subject["subject_name"]).values('level','pk')
        for temp in q:
            if(temp["level"]=='easy' and easy_count < 2):
                question_list.append(temp["pk"])
                easy_count=easy_count+1
            elif(temp["level"]=='hard' and hard_count < 2):

                question_list.append(temp["pk"])
                hard_count=hard_count+1
            elif(temp["level"] == 'moderate' and medium_count < 2):
                question_list.append(temp["pk"])
                medium_count = medium_count + 1
                
        easy_count=0
        hard_count=0
        medium_count=0
        questions_list.extend(question_list)
        question_list=[]
    if QuestionSetMain.objects.all().count() > 0:
        QSet=QuestionSetMain.objects.create(Question_number=str(QuestionSetMain.objects.all().count()+1))
    else:
        QSet=QuestionSetMain.objects.create(Question_number="1")
    for x in questions_list:
        temp=Question.objects.get(pk=x)
        if temp.level=="easy":
            
            total=total+1
            time=time+20
        elif temp.level=="hard":
            
            total=total+3
            time=time+50
        else:
          
            total=total+2
            time=time+35
        QSet.Question.add(temp)
    QSet.total_marks=total
    QSet.time=time
    QSet.student_id=Student_detail.objects.get(email_id=id)
    QSet.save()
    
    return QSet
class Question_paper_Main(View):
    template_name ="questionpapermain.html"
    def get(self,request,*args,**kwargs):
        id=request.user
        temp=question_array_main(id)
        return render(request,self.template_name,{'temp':temp})
    def post(self,request,*args,**kwargs):
        obj=QuestionSetMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last()
        topic_array=[]
        marks_array=[]
        total_array=[]
        percentage_array=[]
        temp={}
        marks=0.0
        total=0
        percentage=0.0
        req='post'
        for question in obj.Question.all():
            if question.subject_name.subject_name not in topic_array:
                topic_array.append(question.subject_name.subject_name)
        for x in topic_array:
            marks_array.append(0)
            total_array.append(0)
            percentage_array.append(0.00)
        for question in obj.Question.all():
            index=topic_array.index(question.subject_name.subject_name)
            if question.level=="easy":
                total_array[index]=total_array[index]+1
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+1
            elif question.level=="hard":
                total_array[index]=total_array[index]+3
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+3
            else:
                total_array[index]=total_array[index]+2
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+2
        for  x in range(0,len(topic_array)):
            percentage_array[x]=math.ceil(marks_array[x]/total_array[x]*100)
        marks_dict={}
        for x in range(0,len(percentage_array)):
            marks_dict[topic_array[x]]=percentage_array[x]
        MarksMain.objects.create(student_id=Student_detail.objects.get(email_id=request.user),marks=marks_dict,Qset=QuestionSetMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last())
        obj=Progress.objects.get(stud_id=Student_detail.objects.get(email_id=request.user))
        for x in range(0,len(topic_array)):
            if obj.Status == 'n/a':
                marks=marks+marks_array[x]
            else:
                marks=int(((marks+marks_array[x])+int(obj.marks[topic_array[x]]))/2)
                marks_dict[topic_array[x]]=int((marks_dict[topic_array[x]]+int(obj.marks[topic_array[x]]))/2)
            total=total+total_array[x]
        
        obj.marks=marks_dict
        obj.Total=math.ceil(marks/total*100)
        if obj.Total < 35:
            obj.Status = 'weak'
            obj.save()
            return HttpResponseRedirect(reverse_lazy('assign'))
        elif obj.Total < 75:
            obj.Status = 'average'
            obj.save()
            return HttpResponseRedirect(reverse_lazy('Remedial'))
        else:
            obj.Status = 'above average'
            obj.save()
            return HttpResponseRedirect(reverse_lazy('ExtraPractice'))

class Assign(View):
    def get(self, request,*args,**kwargs):
        obj=MarksMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last()
        for sub,val in obj.marks.items():
            if int(val) < 25:
                obj2=Assignment_question.objects.filter(subject_name__subject_name=sub)
                for temp in obj2:
                    if assignment_student.objects.filter(assigment_id=temp,Stud_id=Student_detail.objects.get(email_id=request.user)).count() < 1:
                        obj3=assignment_student.objects.create(assigment_id=temp,Stud_id=Student_detail.objects.get(email_id=request.user))
                        Tasks.objects.create(Types='Assignment',stud_id=Student_detail.objects.get(email_id=request.user),task_id=obj3.pk,Date_of_Completion=datetime.date.today()+ datetime.timedelta(days=temp.day),Teacher_assigned=Teacher_detail.objects.filter(subjects__subject_name=sub).first())
        return HttpResponseRedirect(reverse_lazy('Report'))
class Remedial(View):
    def get(self, request,*args,**kwargs):
        obj=MarksMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last()
        for sub,val in obj.marks.items():
            if int(val) < 25:
                obj2=RemedialCourse.objects.filter(subject__subject_name=sub)
                for temp in obj2:
                    obj3=RemedialCourse.objects.get(pk=temp.pk)
                    if obj3.user.filter(email_id=request.user).exists:
                        pass
                    else:
                        obj3.user.add(Student_detail.objects.get(email_id=request.user))
                        Tasks.objects.create(Types='Remedial',stud_id=Student_detail.objects.get(email_id=request.user),task_id=obj3.pk,Date_of_Completion=datetime.date.today()+ datetime.timedelta(days=temp.days),Teacher_assigned=Teacher_detail.objects.filter(subjects__subject_name=sub).first())
        return HttpResponseRedirect(reverse_lazy('Report'))
class ExtraPractice(View):
    def get(self, request,*args,**kwargs):
        obj=MarksMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last()
        for sub,val in obj.marks.items():
            if int(val) < 25:
                obj2=ExtraPratice_question.objects.filter(subject_name__subject_name=sub)
                for temp in obj2:
                    if ExtraPratice_student.objects.filter(assigment_id=temp,Stud_id=Student_detail.objects.get(email_id=request.user)).count() < 1:
                        obj3=ExtraPratice_student.objects.create(assigment_id=temp,Stud_id=Student_detail.objects.get(email_id=request.user))
                        Tasks.objects.create(Types='ExtraPractice',stud_id=Student_detail.objects.get(email_id=request.user),task_id=obj3.pk,Date_of_Completion=datetime.date.today()+ datetime.timedelta(days=temp.day),Teacher_assigned=Teacher_detail.objects.filter(subjects__subject_name=sub).first())
        return HttpResponseRedirect(reverse_lazy('Report'))
class Report(View):
    template_name ="report1.html"
    def get(self, request,*args,**kwargs):
        temp={}
        temp['Date']=datetime.date.today()
        obj=MarksMain.objects.filter(student_id=Student_detail.objects.get(email_id=request.user)).last()
        user=UserProfile.objects.get(email_id=request.user)
        temp['Name']=user.first_name+" "+user.last_name
        temp["id"]=obj.Qset.id
        temp["rid"]=obj.id
        temp['marks']=obj.marks
        return render(request,self.template_name,{'temp':temp})


def Question_download(request,Qset_id):
    Qset=QuestionSetMain.objects.get(id=Qset_id)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="mypdf.pdf"'

    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    Q_id='Question paper id : ' + str(Qset.Question_number)
    # Start writing the PDF here
    p.drawString(10, 762, 'total marks : ' +str(Qset.total_marks))
    p.drawString(250, 762, Q_id )
    p.drawString(490, 762,'time : '+str(int(Qset.time/60))+' : '+str(int(Qset.time%60)))
    # End writing
    q=1
    y=742
    for question in Qset.Question.all():
        if y <= 40:
            p.showPage()
            y=762
        if len(question.question) > 100:
            p.drawString(10, y,'Q'+str(q)+". "+ question.question[0:99] +"-" )
            p.drawString(10, y-15, question.question[99:(len(question.question)-1)]  )
        else:
            p.drawString(10, y,'Q'+str(q)+". "+ question.question )
        p.drawString(10, y-30, 'A. ' + str(question.optionA))
        p.drawString(10, y-50, 'B. ' + str(question.optionB))
        p.drawString(10, y-70, 'C. ' + str(question.optionC))
        p.drawString(10, y-90, 'D. ' + str(question.optionD))
        p.drawString(10, y-110, 'Answer : ' + str(question.Answer))
        y=y-130
        q=q+1
    p.save()

    pdf = buffer.getvalue()
    buffer.close()

    response.write(pdf)
    response = HttpResponse(pdf, content_type="application/zip")
    response['Content-Disposition'] = 'inline; filename='+str(Qset_id)
    return response

def Report_download(request,Qset_id):
    Marks=MarksMain.objects.get(id=Qset_id)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="mypdf.pdf"'

    buffer = BytesIO()
    p = canvas.Canvas(buffer)

    #logo = ImageReader('https://127.0.0.1:9000/static/images/login/logo.jpeg')
    #p.drawImage(logo, 10, 10, mask='auto')
    p.drawString(10, 752,'Stud_id:'+ Marks.student_id.email_id.email)
    p.drawString(10, 732,'Date:' +str(Marks.Date))
    p.drawString(10, 712,'Qcode:' +Marks.Qset.Question_number)
    p.drawString(10, 692,'Marks')
    yaxis=672
    for x,y in Marks.marks.items():
        p.drawString(10,yaxis,str(x)+" : "+str(y))
        yaxis=yaxis-20

    p.save()

    pdf = buffer.getvalue()
    buffer.close()

    response.write(pdf)
    response = HttpResponse(pdf, content_type="application/zip")
    response['Content-Disposition'] = 'inline; filename='+str(Marks.id)
    return response
    