from django.db import models
from django.conf import settings
from django.core.validators import RegexValidator
from django.core.validators import MaxValueValidator, MinValueValidator


from semester.models import Semester
from subject.models import Subject
from django.db import models,signals
from django.db.models.signals import pre_save
from django.contrib.auth.models import User

class UserLogin(models.Model):
    """Represent users' logins, one per record"""
    user = models.ForeignKey(User,
    	on_delete=models.CASCADE) 
    timestamp = models.DateTimeField()

def user_presave(sender, instance, **kwargs):
    if instance.last_login:
        old = instance.__class__.objects.get(pk=instance.pk)
        if instance.last_login != old.last_login:
            instance.userlogin_set.create(timestamp=instance.last_login)

pre_save.connect(user_presave, sender=User)


# Create your models here.
def upload_location(instance,filename):
	return "%s/%s"%(instance.id,filename)
# Create your models here.
class UserProfile(models.Model):
	prefix			=models.CharField(max_length=4)
	first_name		=models.CharField(max_length=25)
	last_name		=models.CharField(max_length=25)
	usertype		=models.CharField(max_length=25,null=True)
	email_id		=models.ForeignKey(
						settings.AUTH_USER_MODEL,
						on_delete=models.CASCADE,null=True
						)
	phone_regex = RegexValidator(regex=r'^\+?1?\d{10,15}$', message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")
	number = models.CharField(validators=[phone_regex], max_length=17, blank=True) 
	image			=models.ImageField(
					upload_to="upload_location",
					null=True,blank=True,
					width_field="width_field",
					height_field="height_field"
					)
	height_field=models.IntegerField(default=10)
	width_field=models.IntegerField(default=10)
	date_of_birth	=models.DateField(auto_now=False, auto_now_add=False)
	time_stamp		=models.DateField(auto_now_add=True)
class Student_detail(models.Model):
	Stud_id 		=models.PositiveSmallIntegerField()
	stream			=models.CharField(max_length=8)
	semester		=models.ForeignKey(
       			 	'semester.Semester',
        			on_delete=models.CASCADE,
        			null=True
        			)
	email_id		=models.ForeignKey(
						settings.AUTH_USER_MODEL,
						on_delete=models.CASCADE,null=True
						)
	current			=models.BooleanField(default=True)
class Teacher_detail(models.Model):
	teacher_id 		=models.PositiveSmallIntegerField()
	email_id		=models.ForeignKey(
						settings.AUTH_USER_MODEL,
						on_delete=models.CASCADE,null=True
						)
	subjects		=models.ManyToManyField(
        			'subject.Subject'
   					 )
	type_option		=models.CharField(max_length=8)