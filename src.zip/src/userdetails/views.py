from django.shortcuts import render,redirect
from django.views import generic
from django.views.generic import CreateView,TemplateView,UpdateView
from django.urls import reverse_lazy
from django.contrib.sites.shortcuts import get_current_site
from django.http import HttpResponse,HttpResponseRedirect
from django.db import IntegrityError
from django.conf import settings
from django.template.loader import get_template
from django.core.mail import send_mail
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.sites.models import Site
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate,update_session_auth_hash
from django import forms
from django.contrib.auth.models import User
from django.contrib import messages
from django.forms.widgets import PasswordInput, TextInput
from django.urls import reverse_lazy

from simple_history import register
import sendgrid
import os
from sendgrid.helpers.mail import *
from dal import autocomplete

from task_assign.models import Progress,Tasks
from subject.models import Subject
from question.models import Question
from study_docs.models import Docs
from assignment.models import Assignment_question,assignment_student
from semester.models import Semester
from starttest.models import Marks,Topic
from bridge_course.models import Course
from remediallecture.models import RemedialCourse
from extrapractice.models import ExtraPratice_question,ExtraPratice_student


from .tokens import account_activation_token
from .models import Student_detail,Teacher_detail,UserProfile,UserLogin
from .forms import StudentUserCreationMultiForm,TeacherUserCreationMultiForm,CustomPasswordChangeForm

class SignUpASView(TemplateView):

    template_name = "signupas.html"

def ChangeSemester(self):
    students=Student_detail.objects.all()
    for student in students:
        if int(student.semester.semester) == 6:
            student.semester=None
            student.current=False
            student.save()
            user=User.objects.get(email=student.email_id)
            user.is_active =False
            user.save()
        else:
            student.semester=Semester.objects.get(semester=str(int(student.semester.semester)+1))
            student.save()
    return HttpResponseRedirect(reverse_lazy('home')) 
register(User)
class SubjectAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        # Don't forget to filter out results depending on the visitor !

        qs =Subject.objects.all()

        if self.q:
            qs = qs.filter(subject_name__istartswith=self.q)

        return qs

class StudentUserSignupView(CreateView):
    form_class = StudentUserCreationMultiForm
    success_url = reverse_lazy('login')
    template_name ="signup.html"
    def form_valid(self, form):
        try:
            current_site = get_current_site(None)
            user = form['user'].save(commit=False)
            user.username=form['user'].cleaned_data['email']
            user.is_active = False
            user.save()
            UserProfile = form['UserProfile'].save()
            UserProfile.email_id = user
            UserProfile.usertype ="student"
            UserProfile.save()
            Student_detail =form['Student_detail'].save()
            Student_detail.email_id = user
            Student_detail.save()
            Progress.objects.create(stud_id=Student_detail,Status='n/a')
            
            from_email=settings.DEFAULT_FROM_EMAIL
            mail_subject = 'Activate your blog account.'
            message = render_to_string('acc_active_email.html', {
            'user': user,
            'domain': current_site.domain,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(),
            'token':account_activation_token.make_token(user),
                })
            to_email = [user.email]
            send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
            return super(StudentUserSignupView, self).form_valid(form)
        except IntegrityError:
            return HttpResponse("ERROR: "+form['user'].cleaned_data['email']+" already exists!")

class TeacherUserSignupView(CreateView):
    form_class = TeacherUserCreationMultiForm
    success_url =  reverse_lazy('login')
    template_name ="signup.html"
    def form_valid(self, form):
        try:
            current_site = get_current_site(None)
            user = form['user'].save(commit=False)
            user.username=form['user'].cleaned_data['email']
            user.is_active = False
            user.save()
            UserProfile = form['UserProfile'].save()
            UserProfile.email_id = user
            UserProfile.usertype ="teacher"
            UserProfile.save()
            Teacher_detail =form['Teacher_detail'].save()
            Teacher_detail.email_id = user
            Teacher_detail.save()
            print(user.pk)
            from_email=settings.DEFAULT_FROM_EMAIL
            mail_subject = 'Activate your blog account.'
            message = render_to_string('acc_active_email.html', {
            'user': user,
            'domain': current_site.domain,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(),
            'token':account_activation_token.make_token(user),
                })
            to_email = [user.email]
            send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
            return super(TeacherUserSignupView, self).form_valid(form)
        except IntegrityError:
            return HttpResponse("ERROR: "+form['user'].cleaned_data['email']+" already exists!")


def activate(request, uidb64, token):
    try:
        uid = uid = urlsafe_base64_decode(uidb64).decode()

        user = User.objects.get(pk=uid)
        
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        # return redirect('home')
        return HttpResponse('Thank you for your email confirmation. Now you can login your account.')
    else:
        return HttpResponse('Activation link is invalid!')
class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=TextInput(attrs={'class':'validate','placeholder': 'Email'}))
    password = forms.CharField(widget=PasswordInput(attrs={'placeholder':'Password'}))

def change_password(request):
    if UserProfile.objects.filter(email_id=request.user, usertype__iexact='student'):
        if UserLogin.objects.filter(user=request.user ).count() < 2  and Marks.objects.filter(student_id__email_id=request.user).count() < 1 :
                return HttpResponseRedirect(reverse_lazy('trial'))
        else:     
            progress= Progress.objects.filter(stud_id__email_id=request.user)
            study=Docs.objects.filter(approved=True).order_by('-id')
            assignment_id= assignment_student.objects.filter(Stud_id__email_id=request.user,status=False).values('assigment_id')
            practice_id=ExtraPratice_student.objects.filter(Stud_id__email_id=request.user,status=False).values('ExtraPratice_id')
            
            sassignment=Assignment_question.objects.filter(assigment_id=None)
            spractice=ExtraPratice_question.objects.filter(ExtraPratice_id=None)
            for id in practice_id:
                spractice= spractice | ExtraPratice_question.objects.filter(ExtraPratice_id=id["ExtraPratice_id"])
            for id in assignment_id:
                sassignment=sassignment | Assignment_question.objects.filter(assigment_id=id["assigment_id"])
            course=Course.objects.filter(user__email_id=request.user)
            remedial=RemedialCourse.objects.filter(user__email_id=request.user)
 
            username=UserProfile.objects.filter(email_id=request.user)

                
            if request.method == 'POST':
                form = CustomPasswordChangeForm(request.user, request.POST)
                if form.is_valid():
                    user = form.save()
                    update_session_auth_hash(request, user)  # Important!
                    messages.success(request, 'Your password was successfully updated!')
                    return redirect('home')
                else:
                    messages.error(request, 'Please correct the error below.')
            else:
                form = CustomPasswordChangeForm(request.user)
            return render(request, 'change_password.html',
                 {
                        'form': form,
                        'username':username,
                        'study':study,
                        'sassignment':sassignment,
                        'course':course,
                        'remedial':remedial,
                        'progress':progress,
                        'spractice':spractice
                    })
    
    else: 
        studentname =UserProfile.objects.all()
        student=Tasks.objects.filter(Teacher_assigned__email_id=request.user)
        topics=Topic.objects.filter(teacher__email_id=request.user)
        bridgecourse=Course.objects.filter(title=' ')
        remediallecture=RemedialCourse.objects.filter(title='')
        for topic in topics:
            bridgecourse = bridgecourse | Course.objects.filter(Topic=topic).order_by('-pk')
        username=UserProfile.objects.filter(email_id=request.user)
        subjects=Teacher_detail.objects.filter(email_id=request.user).values('subjects__subject_name')
        doc=Docs.objects.filter(subject__subject_name='')
        assignment=Assignment_question.objects.filter(subject_name__subject_name='')
        q=Question.objects.filter(subject_name__subject_name='')
        extra= ExtraPratice_question.objects.filter(subject_name__subject_name='')
        for temp in subjects: 
            for value in temp.values():
                doc = doc | Docs.objects.filter(subject__subject_name=value,approved=False,disapproved=False).order_by('-id')
                q = q | Question.objects.filter(subject_name__subject_name=value).order_by('-id')
                assignment = assignment | Assignment_question.objects.filter(subject_name__subject_name=value).order_by('-pk')
                remediallecture= remediallecture | RemedialCourse.objects.filter(subject__subject_name=value).order_by('-pk')
                extra = extra | ExtraPratice_question.objects.filter(subject_name__subject_name=value).order_by('-pk')
        doc=doc[0:3]
        student=student[0:5]
        assignment=assignment[0:5]
        que=q[0:5]
        bridgecourse=bridgecourse[0:5]
        remediallecture=remediallecture[0:5]
        if request.method == 'POST':
            form = CustomPasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)  # Important!
                messages.success(request, 'Your password was successfully updated!')
                return redirect('home')
            else:
                messages.error(request, 'Please correct the error below.')

        else:
            form = CustomPasswordChangeForm(request.user)
        return render(request, 'change_password.html', {
                'form': form,
                'que':que,
                'username':username,
                'docs':doc,
                'assignment':assignment,
                'bridgecourse':bridgecourse,
                'remediallecture':remediallecture,
                'Topic':topics,
                'student':student,
                'studentname':studentname,
                'extra':extra

            })
    
class HomeView(TemplateView):
    template_name="home.html"
    

