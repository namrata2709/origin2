from django.urls import path

from .views import ChangeSemester,SignUpASView

urlpatterns = [
   path('ChangeSemester/',ChangeSemester,name='ChangeSemester'),
   path('signupas/',SignUpASView.as_view(),name='signupas'),
   
]