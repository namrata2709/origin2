from django import forms
from multiform import MultiForm,MultiModelForm
from django.core.validators import MaxValueValidator, MinValueValidator
from semester.models import Semester
from subject.models import Subject
from .models import Student_detail,UserProfile,Teacher_detail
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from .tokens import account_activation_token
from django.contrib.sites.shortcuts import get_current_site
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.sites.models import Site
from dal import autocomplete
from django.forms.widgets import CheckboxSelectMultiple
from django.forms.widgets import PasswordInput


class CustomPasswordChangeForm(PasswordChangeForm):
    old_password=forms.CharField(widget=PasswordInput(attrs={'placeholder':'old_password'}))
    new_password1=forms.CharField(widget=PasswordInput(attrs={'placeholder':'new_password'}))
    new_password2=forms.CharField(widget=PasswordInput(attrs={'placeholder':'new_password_confirmation'}))

class SignupForm(UserCreationForm):  
    class Meta:
        model = User
        fields = ( "email", "password1", "password2")
    def __init__(self, *args, **kwargs):
        super(SignupForm, self).__init__(*args, **kwargs)
        for fieldname in [ 'email','password1', 'password2']:
            self.fields[fieldname].help_text = None
            self.fields[fieldname].widget.attrs.update({'style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'})

class StudentRegisterForm(forms.ModelForm):
	class Meta:
		stream_list=(('',''),('commerce','commerce'),('science','science'))
		model = Student_detail
		widgets = {
            'semester':forms.Select(attrs={'style': 'margin-bottom:30px;'}),
			'stream':forms.Select(choices=stream_list,attrs={'style': 'color: #555;margin-bottom:30px;'}),
             'Stud_id':forms.TextInput(attrs={'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'}),
        }
		fields = ['Stud_id','semester','stream']

class UserRegisterForm(forms.ModelForm):
	class Meta:
		pre=(('',''),('miss','miss'),('mr','mr'),('mrs','mrs'))
		model = UserProfile
        
		widgets = {

			'prefix':forms.Select(choices=pre,attrs={'style': 'color: #555;margin-bottom:30px;'}),
            'first_name': forms.TextInput(attrs={'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'}),
            'last_name':forms.TextInput(attrs={'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'}),
            'number':forms.NumberInput(attrs={'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'}),
            'date_of_birth':forms.DateInput(
            attrs={
                'id': 'datepicker',
                'type': 'text',
                'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;margin-top:30px;'}
            )
                                      
        }
		fields =['prefix','first_name','last_name','number','image','date_of_birth']

        
	
class TeacherRegisterForm(forms.ModelForm):
    class Meta:
        TypeChoice=(('core','core'),('external','external'))
        model = Teacher_detail
        widgets = {
            'teacher_id':forms.NumberInput(attrs={'class': 'input--style-1','style': 'color: #555;margin-bottom:30px;border-bottom: 2px solid #ccc;position: relative;padding: 9px 0;opacity: 1;'}),
			'type_option':forms.Select(choices=TypeChoice,attrs={'style': 'color: #555;margin-bottom:30px;'}),
            'subjects':autocomplete.ModelSelect2Multiple(url='subjects-autocomplete',attrs={'style': 'color: #555;margin-bottom:30px;'})
        }
        fields = ['subjects','teacher_id','type_option']
    
class  TeacherUserCreationMultiForm(MultiModelForm):
    base_forms = {
        'user': SignupForm,
        'UserProfile': UserRegisterForm,
        'Teacher_detail':TeacherRegisterForm
    }

class  StudentUserCreationMultiForm(MultiModelForm):
    base_forms = {
        'user': SignupForm,
        'UserProfile': UserRegisterForm,
        'Student_detail':StudentRegisterForm
    }
    