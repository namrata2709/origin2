from django.db import models

from userdetails.models import Teacher_detail,Student_detail
from subject.models import Subject

def upload_location(instance,filename):
	return "%s/%s"%(instance.ExtraPratice_name,filename)
class ExtraPratice_question(models.Model):
	teacher_id=models.ForeignKey(
       			 	'userdetails.Teacher_detail',
        			on_delete=models.CASCADE,
        			null=True
        			)
	ExtraPratice_id=models.AutoField(primary_key=True)
	ExtraPratice_name=models.CharField(max_length=50)
	ExtraPratice_details=models.CharField(max_length=500)
	document=models.FileField(upload_to=upload_location)
	day=models.IntegerField()
	subject_name=models.ForeignKey(
        'subject.Subject',
        on_delete=models.CASCADE,
    )
	def __str__(self):            
		return self.ExtraPratice_name

class ExtraPratice_student(models.Model):
	ExtraPratice_id=models.ForeignKey(
       			 	'ExtraPratice_question',
        			on_delete=models.CASCADE,
        			)
	Stud_id 		=models.ForeignKey(
       			 	'userdetails.Student_detail',
        			on_delete=models.CASCADE,
        			)
	status=models.BooleanField(default=False)
class ExtraPratice_submission(models.Model):
	ExtraPratice_id=models.ForeignKey(
       			 	'ExtraPratice_question',
        			on_delete=models.CASCADE,
        			null=True
        			)
	document=models.FileField(
		upload_to="upload_location",
		)
	approve=models.BooleanField(default=False)
	disapprove=models.BooleanField(default=False)
	relief=models.BooleanField(default=False)
	reason_for_relif=models.CharField(max_length=150,null=True)
		