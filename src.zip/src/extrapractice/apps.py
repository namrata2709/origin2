from django.apps import AppConfig


class ExtrapracticeConfig(AppConfig):
    name = 'extrapractice'
