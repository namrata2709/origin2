from django.urls import path

from .views import (
					ExtraPraticeCreate,
					ExtraPraticeUpdate,
					ExtraPraticeDelete,
					ExtraPraticeDetailView,
					ExtraPraticeListView,
					ExtraPraticedownload,
					ExtraPracticeApproveView,
					ExtraPracticeDisapprove,
					ExtraPracticeApprove,
					Student_ExtraPractice_detail,
					
					)

urlpatterns = [
   path('detail/<int:pk>',ExtraPraticeDetailView.as_view(),name='ExtraPraticeDetailView'),
   path('',ExtraPraticeListView.as_view(),name='ExtraPraticeListView'),
   path('add/',ExtraPraticeCreate.as_view(),name='ExtraPraticeAdd'),
   path('update/<int:pk>',ExtraPraticeUpdate.as_view(),name='ExtraPraticeUpdate'),
   path('delete/<int:pk>',ExtraPraticeDelete.as_view(),name='ExtraPraticeDelete'),

   path('download/<int:id>/', ExtraPraticedownload,name='ExtraPraticedownload'),
   path('disapprove/<int:id>/', ExtraPracticeDisapprove, name='ExtraPracticeDisapprove'),
   path('approve/<int:id>/', ExtraPracticeApprove, name='ExtraPracticeApprove'),
   path('approveview/',ExtraPracticeApproveView.as_view(),name='ExtraPracticeApproveView'),
   path('student/',Student_ExtraPractice_detail.as_view(),name='Student_ExtraPractice_detail'),
]