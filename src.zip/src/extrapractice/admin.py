from django.contrib import admin

# Register your models here.
from .models import ExtraPratice_question,ExtraPratice_student,ExtraPratice_submission
# Register your models here.

admin.site.register(ExtraPratice_question)

admin.site.register(ExtraPratice_submission)
admin.site.register(ExtraPratice_student)