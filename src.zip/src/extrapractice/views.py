from django.shortcuts import render
from django.views import generic
from django.http import HttpResponse #used for download
from django.conf import settings #used for download
from django.views.generic import ListView,DetailView,View,CreateView,DeleteView,UpdateView,TemplateView
from django.contrib.auth.models import User
from django.urls import reverse_lazy
from django.core.mail import send_mail
from django.template.loader import render_to_string

import os#used for download

from userdetails.models import Teacher_detail


from .models import ExtraPratice_question,ExtraPratice_submission,ExtraPratice_student
from .forms import ExtraPraticeadd,SubmitExtraPractice


def ExtraPraticedownload(request, id):
    path=ExtraPratice_question.objects.get(pk=id) 
    obj=str(path.document)
    file_path = os.path.join(settings.MEDIA_ROOT, obj)
    if os.path.exists(file_path):
        #return  HttpResponse(path)
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/zip")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404
    return  HttpResponse(path)


class ExtraPraticeCreate(CreateView):
    model =ExtraPratice_question
    form_class = ExtraPraticeadd
    success_url = reverse_lazy('ExtraPraticeListView')
    template_name ="ExtraPratice_add.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(ExtraPraticeCreate,self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    def form_valid(self, form):
        ExtraPratice = form.save(commit=False)
        ExtraPratice.teacher_id=Teacher_detail.objects.get(email_id=self.request.user)
        ExtraPratice.save()
        return super(ExtraPraticeCreate, self).form_valid(form)
class ExtraPraticeUpdate(UpdateView):
    model =ExtraPratice_question
    template_name ="ExtraPratice_add.html"
    form_class = ExtraPraticeadd
    success_url = reverse_lazy('ExtraPraticeListView')
    def get_form_kwargs(self, **kwargs):
        kwargs = super(ExtraPraticeUpdate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    def form_valid(self, form):
        #try:
        ExtraPratice = form.save(commit=False)
        ExtraPratice.teacher_id=Teacher_detail.objects.get(email_id=self.request.user)
        ExtraPratice.save()
        return super(ExtraPraticeUpdate, self).form_valid(form)
class ExtraPraticeDelete(DeleteView):
    model = ExtraPratice_question
    template_name ="ExtraPratice_delete.html"
    success_url = reverse_lazy('ExtraPraticeListView')

class ExtraPraticeDetailView(DetailView):
	model=ExtraPratice_question
	template_name="ExtraPratice_detail.html"

class ExtraPraticeListView(ListView):
	model=ExtraPratice_question
	context_object_name = 'ExtraPratice'
	template_name="ExtraPratice_list.html"

class Student_ExtraPractice_detail(View):
    form_class = SubmitExtraPractice
    model=ExtraPratice_submission
    initial = {'key': 'value'}
    template_name = 'student_ExtraPractice.html'
    def get(self, request, *args, **kwargs):
        assign=ExtraPratice_question.objects.get(pk=kwargs['assign_id'])
        submit='false'
        if ExtraPratice_submission.objects.filter(ExtraPratice_id=assign,disapprove=False).exists() :
            submit='already'
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form , 'assign' :assign,'submit':submit })

    def post(self, request, *args, **kwargs):

        assign=ExtraPratice_question.objects.get(pk=kwargs['assign_id'])
        form = self.form_class(request.POST, request.FILES)
        if form.is_valid():   
            asssub=ExtraPratice_submission.objects.create(document=form.cleaned_data['document'])
            asssub.ExtraPratice_id=assign
            asssub.Stud_id=Student_detail.objects.get(email_id=self.request.user)
            asssub.save()
            user=assign.teacher_id.email_id
            from_email=settings.DEFAULT_FROM_EMAIL
            subject='An new Practice paper has been submitted by ' +asssub.Stud_id.email_id.email +'\nPlease approve or disapprove it '
            mail_subject = 'new Extra Practice Assignment '
            message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
            to_email = [user.email]
            send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
        return HttpResponseRedirect(reverse_lazy('Student_ExtraPractice_detail',kwargs={'assign_id':self.kwargs['assign_id']}))

class ExtraPracticeApproveView(TemplateView):
    template_name="ExtraPracticeApprove.html"
    def get_context_data(self,*args,**kwargs):
        if Teacher_detail.objects.filter(email_id=self.request.user):
            assign=ExtraPratice_question.objects.filter(teacher_id__email_id=self.request.user)
            context={}
            objects=ExtraPratice_submission.objects.filter(document=None)
            for x in assign:
                objects=objects | ExtraPratice_submission.objects.filter(ExtraPratice_id=x)

            context={"obj":objects}
            return context
def ExtraPracticeDisapprove(request,id):
    obj=ExtraPratice_submission.objects.get(pk=id ) 
    user=obj.Stud_id.email_id
    obj.disapprove=True
    from_email=settings.DEFAULT_FROM_EMAIL
    subject='Your Practice paper has been disapproved \n  name ' +obj.assigment_id.Assignment_name +'\nplease submit it again'
    mail_subject = 'Practice paper status'
    message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
    to_email = [user.email]
    send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
    
    obj.save()
    return HttpResponseRedirect(reverse_lazy('AssignmentApproveView'))
def ExtraPracticeApprove(request,id):
    obj=ExtraPratice_submission.objects.get(pk=id )
    user=obj.Stud_id.email_id 
    obj.approve=True
    obj.save()
    from_email=settings.DEFAULT_FROM_EMAIL
    subject='Your Practice paper has been approved \n name ' +obj.assigment_id.Assignment_name +'\nThank You'
    mail_subject = 'Practice paper status'
    message = render_to_string('email.html', {
            'user': user,
            'subject': subject,
                })
    
    to_email = [user.email]
    send_mail(mail_subject,message,from_email,to_email,fail_silently=True)
    obj1= ExtraPratice_student.objects.get(assigment_id=id)
    obj1.status=True
    obj1.save()
    print(obj.assigment_id.pk)
    obj2=Tasks.objects.get(Teacher_assigned=Teacher_detail.objects.get(email_id=request.user),Types='Extra Practice',task_id=obj1.pk,stud_id=obj1.Stud_id)
    obj2.Status=True
    obj2.save()
    return HttpResponseRedirect(reverse_lazy('AssignmentApproveView'))



