from django import forms


from .models import ExtraPratice_question,ExtraPratice_submission

from userdetails.models import Teacher_detail 
from subject.models import Subject
# Create your views here.
class ExtraPraticeadd(forms.ModelForm):
	
	class Meta:
		model = ExtraPratice_question
		fields =('ExtraPratice_name','ExtraPratice_details','document','subject_name','day')
	def __init__(self, user, *args, **kwargs):
	 	super(ExtraPraticeadd, self).__init__(*args, **kwargs)
	 	self.fields['subject_name'].queryset = Subject.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name'))

class SubmitExtraPractice(forms.ModelForm):
	class  Meta:
		model=ExtraPratice_submission
		fields=['document']
		widgets = {
			'document':forms.FileInput(attrs={'class':"btn btn-sn"}),
        }