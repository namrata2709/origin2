from django import forms
from userdetails.models import Teacher_detail
from .models import Question
from subject.models import Subject
class QuestionForm(forms.ModelForm):
	class Meta:
		level_list=(('',''),('easy','easy'),('moderate','moderate'),('hard','hard'))
		Answer_list=(('',''),('A','A'),('B','B'),('C','C'),('D','D'))
		model = Question
		widgets = {
			'level':forms.Select(choices=level_list),
			'Answer':forms.Select(choices=Answer_list),
        }
		fields = ['question','image','optionA','optionB','optionC','optionD','Answer','level','subject_name']
	def __init__(self, user, *args, **kwargs):
	 	super(QuestionForm, self).__init__(*args, **kwargs)

	 	self.fields['subject_name'].queryset = Subject.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name'))
