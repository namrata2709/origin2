from django.db import models


from subject.models import Topic,Subject

# Create your models here.
def upload_location(instance,filename):
	return "%s/%s"%(instance.id,filename)
class Question(models.Model):
	question=models.CharField(max_length=250)
	image=models.ImageField(
		upload_to="upload_location",
		null=True,blank=True,
		width_field="width_field",
		height_field="height_field")
	height_field=models.IntegerField(default=10)
	width_field=models.IntegerField(default=10)
	optionA=models.CharField(max_length=70)		
	optionB=models.CharField(max_length=70)		
	optionC=models.CharField(max_length=70,null=True)		
	optionD=models.CharField(max_length=70,null=True)
	Answer=models.CharField(max_length=10)
	level=models.CharField(max_length=10)
	subject_name=models.ForeignKey(
    	'subject.Subject',
        on_delete=models.CASCADE,
        null=True,
    )
	
    

	def __str__(self):
		return self.question