from django.urls import path

from .views import QuestionAdd,QuestionList,QuestionView,QuestionUpdate,QuestionDelete

urlpatterns = [
    path('', QuestionList.as_view(), name='question_list'),
    path('view/<int:pk>', QuestionView.as_view(), name='question_view'),
    path('add/', QuestionAdd.as_view(), name='question_new'),
    path('edit/<int:pk>', QuestionUpdate.as_view(), name='question_edit'),
    path('delete/<int:pk>', QuestionDelete.as_view(), name='question_delete'),

]