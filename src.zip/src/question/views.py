from django.shortcuts import render
from django.http import HttpResponse
from userdetails.models import Teacher_detail
from django.views.generic import CreateView,ListView,DetailView,UpdateView,DeleteView
from .forms import QuestionForm
from .models import Question
from subject.models import Subject,Topic,Chapter
from django.urls import reverse_lazy
# Create your views here.
class QuestionAdd(CreateView):
    form_class = QuestionForm
    success_url = reverse_lazy('question_list')
    template_name ="question_form.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(QuestionAdd, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    def form_valid(self, form):
    	Question = form.save(commit=False)
    	subject	=Subject.objects.filter(subject_name=Question.subject_name).values('subject_name')
    	for temp in subject:
            for values in temp.values():
                if Teacher_detail.objects.filter(email_id=self.request.user ,subjects__subject_name=values):
                    
                    Question.save()
    	return super(QuestionAdd, self).form_valid(form)
class QuestionList(ListView):
    model=Question
    context_object_name = 'questions'
    template_name ="question_list.html"
    paginate_by = 10
    def get_queryset(self):
        subject=Teacher_detail.objects.filter(email_id=self.request.user).values('subjects__subject_name')
        q=Question.objects.filter(subject_name__subject_name='')
        for temp in subject: 
            for value in temp.values():
                q = q | Question.objects.filter(subject_name__subject_name=value)
        return q
class QuestionView(DetailView):
    model = Question
    template_name ="question_detail.html"

class QuestionUpdate(UpdateView):
    model =Question
    template_name ="question_form.html"
    form_class = QuestionForm
    success_url = reverse_lazy('question_list')
    def get_form_kwargs(self, **kwargs):
        kwargs = super(QuestionUpdate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
class QuestionDelete(DeleteView):
    model = Question
    template_name ="question_confirm_delete.html"
    success_url = reverse_lazy('question_list')

# class UserAnnouncesList(ListView):
#     model = Announce
#     template_name = 'myApp/user_announces_list.html'
#     context_object_name = 'all_announces_by_user'

#     def get_queryset(self):
#         return Announce.objects.filter(owner=self.kwargs['pk'])