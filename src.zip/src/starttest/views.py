from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.views.generic import CreateView,ListView,DetailView,UpdateView,DeleteView
from django.urls import reverse_lazy,reverse
from django.views import View 
from random import shuffle
import datetime  
from datetime import timedelta 
from .models import Topic,Question,QuestionSet,Marks
from .forms import TopicForm,QuestionForm
from userdetails.models import Teacher_detail,Student_detail,UserProfile
from task_assign.models import Tasks
import json
from django.contrib.auth.models import User
from bridge_course.models import Course
import math

# Create your views here.
class QuestionAdd(CreateView):
    form_class = QuestionForm
    success_url = '/starttest/question/'
    template_name ="questions_form.html"
    def get_context_data(self,**kwargs):
        kwargs=super(QuestionAdd,self).get_context_data(**kwargs)
        kwargs['pk']=self.kwargs.get('pk')
        return kwargs

    def form_valid(self, form):
        question = form.save(commit=False)
        question.topic_name=Topic.objects.get(pk = self.kwargs['pk'])
        question.teacher=Teacher_detail.objects.get(email_id = self.request.user)
        question.save()
        return super(QuestionAdd, self).form_valid(form)
class QuestionList(ListView):
    model=Question
    context_object_name = 'questions'
    template_name ="questions_list.html"

class QuestionView(DetailView):
    model = Question
    template_name ="questions_detail.html"

class QuestionUpdate(UpdateView):
    model =Question
    template_name ="questions_form.html"
    form_class = QuestionForm
    success_url = '/starttest/question/'

class QuestionDelete(DeleteView):
    model = Question
    template_name ="questions_confirm_delete.html"
    success_url = '/starttest/question/'


class TopicAdd(CreateView):
    form_class = TopicForm
    success_url = '/starttest/topic/'
    template_name ="topic_form.html"
    def form_valid(self, form):
        topic = form.save(commit=False)
        topic.slug=form.cleaned_data['Topic_name']
        topic.teacher=Teacher_detail.objects.get(email_id = self.request.user)
        topic.save()
        return super(TopicAdd, self).form_valid(form)

class TopicList(ListView):
    model=Topic
    context_object_name = 'topics'
    template_name ="topic_list.html"


class TopicUpdate(UpdateView):
    model =Topic
    template_name ="topic_form.html"
    form_class = TopicForm
    success_url = '/starttest/topic/'


class TopicDelete(DeleteView):
    model = Topic
    template_name ="topic_confirm_delete.html"
    success_url = '/starttest/topic/'
def question_array(id):
    question_list=[]
    question_lists=[]
    total=0
    time=0
    objects=Topic.objects.all()
    for obj in objects:
        questions=Question.objects.filter(topic_name=obj)
        if questions:
            for question in questions:
                question_lists.append(question.pk)
            shuffle(question_lists)
            if questions.count() > 10:
                question_lists=question_lists[0:9]
            question_list.extend(question_lists)
    if QuestionSet.objects.all().count() > 0:
        QSet=QuestionSet.objects.create(Question_number=str(QuestionSet.objects.all().count()+1))
    else:
        QSet=QuestionSet.objects.create(Question_number="1")
    for x in question_list:
        temp=Question.objects.get(pk=x)
        if temp.level=="easy":
            total=total+1
            time=time+20
        elif temp.level=="hard":
            total=total+3
            time=time+50
        else:
            total=total+2
            time=time+35
        QSet.Question.add(temp)
    QSet.marks=total
    QSet.time=time
    QSet.student_id=Student_detail.objects.get(email_id=id)
    QSet.save()
    
    return QSet
class Question_paper(View):
    template_name ="questionpaper.html"
    def get(self,request,*args,**kwargs):
        id=request.user
        temp=question_array(id)
        return render(request,self.template_name,{'temp':temp})
    def post(self,request,*args,**kwargs):
        obj=QuestionSet.objects.filter().last()
        topic_array=[]
        marks_array=[]
        total_array=[]
        percentage_array=[]
        temp=[]
        for question in obj.Question.all():
            if question.topic_name.Topic_name not in topic_array:
                topic_array.append(question.topic_name.Topic_name)
        for x in topic_array:
            marks_array.append(0)
            total_array.append(0)
            percentage_array.append(0.00)
        for question in obj.Question.all():
            index=topic_array.index(question.topic_name.Topic_name)
            if question.level=="easy":
                total_array[index]=total_array[index]+1
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+1
            elif question.level=="hard":
                total_array[index]=total_array[index]+3
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+3
            else:
                total_array[index]=total_array[index]+2
                if question.Answer==request.POST.get(str(question.pk)):
                    marks_array[index]=marks_array[index]+2
        for  x in range(0,len(topic_array)):
            percentage_array[x]=math.ceil(marks_array[x]/total_array[x]*100)
        marks_dict={}
        for x in range(0,len(percentage_array)):
            marks_dict[topic_array[x]]=percentage_array[x]
        marks=Marks.objects.create(student_id=Student_detail.objects.get(email_id=request.user),marks=marks_dict,Qset=obj)
        for x in range(0,len(topic_array)):
            if(marks_dict.get(topic_array[x])<50):
                obj=Topic.objects.filter(Topic_name=topic_array[x]).first()
                if(obj.courses.all().count()>0):
                    for i in obj.courses.all():
                        if i.user.filter(email_id=request.user).count() >0:
                            pass
                        else:
                            task=Tasks.objects.create(stud_id=Student_detail.objects.get(email_id=request.user),Types='Bridge Course',task_id=i.pk,Date_of_Completion=datetime.date.today()+ datetime.timedelta(days=i.days),Teacher_assigned=obj.teacher)
                            i.user.add(Student_detail.objects.get(email_id=request.user))
                            i.save()
            else:
                obj=Topic.objects.filter(Topic_name=topic_array[x]).first()
                if(obj.courses.all().count()>0):
                    for i in obj.courses.all():
                        if i.user.filter(email_id=request.user).exists:
                            task=Tasks.objects.get(task_id=i.pk)
                            task.Status=True
                            task.save()
                            i.user.remove(Student_detail.objects.get(email_id=request.user))
                            i.save()
        return HttpResponseRedirect(reverse_lazy('result'))

class Result(View):
    template_name ="report.html"
    def get(self, request,*args,**kwargs):
        temp={}
        temp['Date']=datetime.date.today()
        obj=Marks.objects.filter(student_id__email_id=self.request.user).last()
        user=UserProfile.objects.get(email_id=request.user)
        temp['Name']=user.first_name+" "+user.last_name
        temp['marks']=obj.marks
        return render(request,self.template_name,{'temp':temp})
    

