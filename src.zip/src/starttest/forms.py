from django import forms
from .models import Topic,Question
class TopicForm(forms.ModelForm):
	class Meta:
		model = Topic
		fields = ['Topic_name']

class QuestionForm(forms.ModelForm):
	class Meta:
		answer_list=(('',''),('A','A'),('B','B'),('C','C'),('D','D'))
		level_list=(('',''),('easy','easy'),('moderate','moderate'),('hard','hard'))
		model = Question
		widgets = {
			'Answer':forms.Select(choices=answer_list),
			'level':forms.Select(choices=level_list),
        }
		fields = ['question','image','optionA','optionB','optionC','optionD','Answer','level']
