from django.apps import AppConfig


class StrattestConfig(AppConfig):
    name = 'strattest'
