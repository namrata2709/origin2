from django.urls import path

from .views import (
					Question_paper,
					TopicAdd,
					TopicList,
					TopicUpdate,
					TopicDelete,
					QuestionList,
					QuestionView,
					QuestionAdd,
					QuestionUpdate,
					QuestionDelete,
					Result,
					)

urlpatterns = [
    path('topic/', TopicList.as_view(), name='startTopic_list'),
    path('topic/add/', TopicAdd.as_view(), name='startTopic_new'),
    path('result/', Result.as_view(), name='result'),
    path('topic/edit/<int:pk>', TopicUpdate.as_view(), name='startTopic_edit'),
    path('topic/delete/<int:pk>', TopicDelete.as_view(), name='startTopic_delete'),
    path('question/', QuestionList.as_view(), name='startquestion_list'),
    path('question/view/<int:pk>', QuestionView.as_view(), name='startquestion_view'),
    path('question/add/<int:pk>', QuestionAdd.as_view(), name='startquestion_new'),
    path('question/edit/<int:pk>', QuestionUpdate.as_view(), name='startquestion_edit'),
    path('question/delete/<int:pk>', QuestionDelete.as_view(), name='startquestion_delete'),
    path('trial/',Question_paper.as_view(),name='trial'),

]