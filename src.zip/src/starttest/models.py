from django.db import models
from django.contrib.postgres.fields import HStoreField

from userdetails.models import Teacher_detail,Student_detail
# Create your models here.
class Topic(models.Model):
	topic_slug=models.SlugField()
	Topic_name=models.CharField(max_length=60,unique=True)
	teacher=models.ForeignKey(
        'userdetails.Teacher_detail',
        on_delete=models.CASCADE,
        )
	def __str__(self):            
		return self.Topic_name
	@property
	def courses(self):
		return self.course_set.all()
	
		
def upload_location(instance,filename):
	return "%s/%s"%(instance.id,filename)
class Question(models.Model):
	question=models.CharField(max_length=250)
	image=models.ImageField(
		upload_to="upload_location",
		null=True,blank=True,
		width_field="width_field",
		height_field="height_field")
	height_field=models.IntegerField(default=10)
	width_field=models.IntegerField(default=10)
	optionA=models.CharField(max_length=70)		
	optionB=models.CharField(max_length=70)		
	optionC=models.CharField(max_length=70,null=True)		
	optionD=models.CharField(max_length=70,null=True)
	Answer=models.CharField(max_length=10)
	level=models.CharField(max_length=10)
	teacher=models.ForeignKey(
        'userdetails.Teacher_detail',
        on_delete=models.CASCADE,
        )
	topic_name=models.ForeignKey(
        'Topic',
        on_delete=models.CASCADE,

    )


	def __str__(self):
		return self.question
class QuestionSet(models.Model):
	Question_number=models.CharField(max_length=10,null=True)
	Question=models.ManyToManyField(
        			'Question'
   					 )
	total_marks=models.IntegerField(null=True)
	time=models.IntegerField(null=True)
	student_id=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True
        )
		
class Marks(models.Model):
	student_id=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True,
        )
	marks=HStoreField(null=True)
	Qset=models.ForeignKey(
        'QuestionSet',
        on_delete=models.CASCADE,
        )
	Date=models.DateField(auto_now=False, auto_now_add=True)
# class video(models.Model):
# 	video_name=models.CharField(max_length=30)
# 	video_description=
# 		