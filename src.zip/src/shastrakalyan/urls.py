""""shastrakalyan URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from subject.views import SubjectCreate,ChapterCreate,TopicCreate,Subject_List
from userdetails.views import TeacherUserSignupView,StudentUserSignupView,activate,LoginForm,change_password,HomeView,SubjectAutocomplete
from django.contrib.auth.views import LoginView,login
from django.urls import path, include,re_path
from django.conf.urls import url

from django.views.generic.base import TemplateView
from study_docs.views import DocumentView,DocumentApproveView,download,DocumentDisapprove,DocumentApprove
from django.views.i18n import JavaScriptCatalog

urlpatterns = [
    path('admin/', admin.site.urls),
    path('question/', include('question.urls')),
    path('subject/', include('subject.urls')),
    path('userdetails/', include('userdetails.urls')),
    path('starttest/', include('starttest.urls')),
    path('exam/', include('exam.urls')),
    path('assignment/', include('assignment.urls')),
    path('extrapractice/', include('extrapractice.urls')),
    path('bridge_course/', include('bridge_course.urls')),
    path('task_assign/', include('task_assign.urls')),
    path('remediallecture/', include('remediallecture.urls')),
    path('feedback/', include('feedback.urls')),
    path('document/approve/',DocumentApproveView.as_view(),name='DocumentApprove'),
    path('subject/add/',SubjectCreate.as_view()),
    path('jsi18n/', JavaScriptCatalog.as_view(), name='javascript-catalog'),
    path('topics/add/',TopicCreate.as_view(),name='TopicCreate'),
    path('student/add/',StudentUserSignupView.as_view(),name="signupstudent"),
    path('document/add/',DocumentView.as_view(),name="studydocsadd"),
    path('teacher/add/',TeacherUserSignupView.as_view(),name="signupteacher"),
    path('login/',login, {'template_name': 'registration/login.html', 'authentication_form': LoginForm},name="login"),
    
    re_path('activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/',
            activate, name='activate'),
    path('accounts/', include('django.contrib.auth.urls')), 
    path('', HomeView.as_view(),name="homecheck"),
    path('success/', TemplateView.as_view(template_name='success.html'),name="success"),
    path('home/', change_password, name='home'),
    path('download/<int:id>/', download,name='download'),
    path('delete/<int:id>/', DocumentDisapprove, name='Documentdisapprove'),
    path('approve/<int:id>/', DocumentApprove, name='Documentapprove'),
    path('subjects-autocomplete/', SubjectAutocomplete.as_view(), name='subjects-autocomplete')

    ]
if settings.DEBUG:
    #urlpatterns += staticfiles_urlpatterns()
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
