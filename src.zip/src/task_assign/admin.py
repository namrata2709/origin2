from django.contrib import admin

# Register your models here.
from .models import Tasks,Progress
# Register your models here.

admin.site.register(Tasks)

admin.site.register(Progress)