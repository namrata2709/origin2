from django.apps import AppConfig


class TaskAssignConfig(AppConfig):
    name = 'task_assign'
