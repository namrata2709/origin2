from django.shortcuts import render
from django.views.generic import CreateView,ListView,DetailView,UpdateView,DeleteView,View
from django.contrib.auth.models import User
# Create your views here.

from userdetails.models import Student_detail,UserProfile
from assignment.models import assignment_student,Assignment_question
from bridge_course.models import Course
from remediallecture.models import RemedialCourse

from .models import Tasks


class Task_View(View):
    template_name = 'task.html'
    def get(self, request, *args, **kwargs):
    	assignment_id= assignment_student.objects.filter(Stud_id__email_id=self.request.user,status=False).values('assigment_id')
    	assignment=Assignment_question.objects.filter(assigment_id=None)
    	for id in assignment_id:
    		assignment=assignment | Assignment_question.objects.filter(assigment_id=id["assigment_id"])
    	course=Course.objects.filter(user__email_id=self.request.user)
    	remedial=RemedialCourse.objects.filter(user__email_id=self.request.user)
    	return render(request, self.template_name, {'assignments':assignment,'courses':course,'remedials':remedial})
	
class Student_List(View):
    template_name="studentlist.html"
    def get(self, request, *args, **kwargs):
        cou=['','Remedial','Bridge Course','Assignment','Extra Practice']
        com=['',False,True]
        studentname =UserProfile.objects.all()
        if self.kwargs["com"] == 0 :
            if self.kwargs["cou"] ==0 :
                student=Tasks.objects.filter(Teacher_assigned__email_id=request.user)
            else:
                student=Tasks.objects.filter(Teacher_assigned__email_id=request.user,Types=cou[self.kwargs["cou"]])
        else:
            if self.kwargs["cou"] ==0 :
                student=Tasks.objects.filter(Teacher_assigned__email_id=request.user,Status=com[self.kwargs["com"]])
            else:
                student=Tasks.objects.filter(Teacher_assigned__email_id=request.user,Types=cou[self.kwargs["cou"]],Status=com[self.kwargs["com"]])


        return render(request, self.template_name, {'studentname':studentname,'student':student})