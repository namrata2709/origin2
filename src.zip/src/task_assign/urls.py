from django.urls import path

from .views import Task_View,Student_List
urlpatterns = [
    path('',Task_View.as_view(),name='Task_View'),
    path('student/<int:com>/<int:cou>',Student_List.as_view(),name='Student_List'),
    
    
]