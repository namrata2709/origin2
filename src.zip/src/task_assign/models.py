from django.db import models
from django.contrib.postgres.fields import HStoreField
from django.contrib.postgres.fields import ArrayField
from userdetails.models import Student_detail,Teacher_detail



#Create your models here.
class Tasks(models.Model):
    Types = (
        ('Remedial', 'Remedial'),
        ('Bridge Course', 'Bridge Course'),
        ('Assignment','Assignment'),
        ('Extra Practice','Extra Practice'),
    )
    stud_id         =models.ForeignKey(
                    'userdetails.Student_detail',
                    on_delete=models.CASCADE,
                    )
    task_id         =models.IntegerField()
    Types           =models.CharField(max_length=20, choices=Types)
    Date_of_Start   =models.DateField(auto_now=False, auto_now_add=True)
    Date_of_Completion=models.DateField(auto_now=False, auto_now_add=False)
    Status          =models.BooleanField(default=False)
    Teacher_assigned=models.ForeignKey(
                    'userdetails.Teacher_detail',
                    on_delete=models.CASCADE,
                    )

class Progress(models.Model):
  status=(
        ('n/a', 'n/a'),
        ('weak', 'weak'),
        ('average','average'),
        ('above average','above average'),
    )
  stud_id         =models.ForeignKey(
                      'userdetails.Student_detail',
                  on_delete=models.CASCADE,
                  )
  marks          =HStoreField(null=True)

  Total           =models.IntegerField(null=True)
  Status          =models.CharField(max_length=20, choices=status)