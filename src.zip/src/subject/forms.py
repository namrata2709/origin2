from django import forms
from semester.models import Semester
from .models import Subject,Topic,Chapter
from userdetails.models import Teacher_detail

class SubjectForm(forms.ModelForm):
	class Meta:
		model = Subject
		fields = ['subject_name','semester']
	def clean(self):
		cleaned_data = self.cleaned_data
		try:
			Subject.objects.get(subject_name=cleaned_data['subject_name'])
		except Subject.DoesNotExist:
			pass
		else:
			raise ValidationError('subject with this Name already exists ')
		return cleaned_data
class ChapterForm(forms.ModelForm):
	class Meta:
		model = Chapter
		fields = ['Chapter_name','subject_name']
	def __init__(self, user, *args, **kwargs):
	 	super(ChapterForm, self).__init__(*args, **kwargs)

	 	self.fields['subject_name'].queryset = Subject.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name'))
	def clean(self):
			cleaned_data = self.cleaned_data
			try:
				Chapter.objects.filter(Chapter_name=cleaned_data['Chapter_name'])
			except Chapter.DoesNotExist:
				pass
			else:
				print()
				raise ValidationError('Chapter with this Name already exists for this subject')
			return cleaned_data

		
class TopicForm(forms.ModelForm):
	class Meta:
		model = Topic
		fields = ['Topic_name','Chapter_name']
		def __init__(self, user, *args, **kwargs):
			super(TopicForm, self).__init__(*args, **kwargs)
			self.fields['Chapter_name'].queryset = Topic.objects.filter(Chapter_name__in=Chapter.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name')))
	
		def clean(self):
			cleaned_data = self.cleaned_data
			try:
				Topic.objects.filter(Chapter_name=cleaned_data['Chapter_name'],Topic_name=cleaned_data['Topic_name'])
			except Topic.DoesNotExist:
				pass
			else:
				raise ValidationError('Topic with this Name already exists for this Chapter')
			return cleaned_data