from django.urls import path

from .views import Subject_List,Chapter_List,ChapterCreate,TopicCreate,Topic_List
urlpatterns = [
    path('',Subject_List.as_view(),name='chapter'),
    path('topic/view/<int:pk>',Topic_List.as_view(),name='topic_list'),
    path('chapter/view/<int:pk>',Chapter_List.as_view(),name='chapter_list'),
    path('chapter/add/',ChapterCreate.as_view(),name='chapter_add'),
    path('topic/add/',TopicCreate.as_view(),name='topic_add'),
    
]