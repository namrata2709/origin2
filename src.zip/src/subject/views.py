from django.shortcuts import render
from django.http import HttpResponse
from django.forms import formset_factory
from django.views.generic import CreateView,ListView,DetailView,UpdateView,DeleteView
from .forms import SubjectForm,ChapterForm,TopicForm
from .models import Subject,Chapter,Topic

from userdetails.models import Teacher_detail
# Create your views here.
class SubjectCreate(CreateView):
    form_class = SubjectForm
    success_url = '/success/'
    template_name ="form_add.html"
class ChapterCreate(CreateView):
    form_class=ChapterForm
    success_url = '/success/'
    template_name ="form_add.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(ChapterCreate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 

class TopicCreate(CreateView):
    form_class = TopicForm
    success_url = '/success/'
    template_name ="form_add.html"
 
class Subject_List(ListView):
    context_object_name = 'subject'
    template_name ="subject_list.html"
    def get_queryset(self):
        q=Teacher_detail.objects.get(email_id=self.request.user)
        return q.subjects.all()
class Chapter_List(ListView):
    context_object_name = 'chapter'
    template_name ="Chapter_list.html"
    def get_context_data(self,**kwargs):
        kwargs=super(Chapter_List,self).get_context_data(**kwargs)
        kwargs['pk']=self.kwargs.get('pk')
        return kwargs
    def get_queryset(self):
        q=Chapter.objects.filter(subject_name=Subject.objects.get(id=self.kwargs['pk']))
        return q

class Topic_List(ListView):
    context_object_name = 'topic'
    template_name ="Topic_list.html"
    def get_context_data(self,**kwargs):
        kwargs=super(Topic_List,self).get_context_data(**kwargs)
        kwargs['pk']=self.kwargs.get('pk')
        return kwargs
    def get_queryset(self):
        q=Topic.objects.filter(Chapter_name=Chapter.objects.get(id=self.kwargs['pk']))
        return q