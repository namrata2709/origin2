from django.db import models


from semester.models import Semester
# Create your models here.
class Subject(models.Model):
	type_list=(
    
        ('practical','practical'),
        ('theory','theory')
    )

	subject_name=models.CharField(max_length=60)
	semester=models.ForeignKey(
        'semester.Semester',
        on_delete=models.CASCADE,
        )
	subject_type=models.CharField(max_length=10,choices=type_list)
	def __str__(self):            
		return self.subject_name

class Chapter(models.Model):
	Chapter_name=models.CharField(max_length=60)
	subject_name=models.ForeignKey(
        'Subject',
        on_delete=models.CASCADE,
        )
	def __str__(self):            
		return self.Chapter_name

class Topic(models.Model):
	Topic_name=models.CharField(max_length=60)
	Chapter_name=models.ForeignKey(
        'Chapter',
        on_delete=models.CASCADE,
        )
	def __str__(self):            
		return self.Topic_name