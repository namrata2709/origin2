<?php
session_start();
if(!isset($_SESSION["user"]))

{
	echo "<script>alert('you are not loged in');location.href = 'login.php';</script>";
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<script>function pass()
{
	var reg=/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
	var passwd=document.getElementById("Password").value;
	if(passwd.match(reg))
	{
		return true;
	}
	else
	{
		alert(" at least one number, one lowercase and one uppercase letter, least six characters");
		return false;
	}
}</script>
	<link rel="stylesheet" href="styles.css">
</head>

<body>
	<div class="wrapper">
   		<div class="header">
			<a href="home.php"><img src="images/images.jpeg"></a>
			<h1><marquee width="1000px">NICE TRIP</marquee></h1>
				<p align="center">You can contact us on our Toll Free number<br>
				<u>+1800 255 9867865</u></p>
		</div>
   		 <div class="container">
    		<img src="images/PicsArt_02-28-04.35.23.png">
			<div class="logo">
				<img src="images/PicsArt_02-28-04.35.23.png">
				<h1>NICE TRIP</h1>
			</div>
		</div>
       	<div class="list">
    		<ul>
    			<li><a href="home.php">Home</a></li>
                <li><a href="add bus schedule.php">Bus Schedule</a></li>
    			<li><a href="addbus.php">Add bus</a></li>
                <li><a href="logout.php">Logout</a></li>
   		 	</ul>	
		</div>
        <div class="home">
			<center>
                <h2>WELCOME TO NICE TRIP.COM-ADMINISTRTIVE HOME</h2>
          </center>
        </div>
        <div class="list1">
        <ul>
            <li><a href="changepassword.php">Change Password</a></li>
            <li><a href="user_details.php">User Details</a></li>
            <li><a href="viewfeedback.php">View feedback</a></li>
        </ul>
   <br><center><h1>Change Password</h1>
  			 <form method="post" onSubmit="return pass();">
           		 <table>
                    <tr>
                    	<td>Enter old password</td>
                        <td><input type="password" id="oldpassword" name="oldpassword"></td>
                    </tr>
                    <tr>
                    	<td>Enter new password</td>
                        <td><input type="password" id="newpassword" name="newpassword" onBlur="return pass();"></td>
                    </tr>
                    <tr>
                    	<td>confirm new password</td>
                        <td><input type="password" id="confirmpassword" name="confirmpassword"></td>
                    </tr>
                    <tr>
                    	<td><button type="submit" name="changepassword" value="changepassword">changepassword</button></td>
                        <td><input type="reset" value="cancel" ></td>
                    </tr>
                </table>
             </form></center>
        </div>
	</div>
        </body>      
</html>
<?php
$servername="localhost";
$username="root";
$password="root";
$dbname="project";
$conn=new MySQLi($servername,$username,$password,$dbname);
if(isset($_POST["changepassword"]))
{
$uname=$_SESSION["user"];
$op=$_POST["oldpassword"];
$np=$_POST["newpassword"];
$cp=$_POST["confirmpassword"];
$temp=0;
if($cp==$np)
{
	$sql=" SELECT Username,Password,Type FROM log_master";
	$result=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_row($result))
	{
	
	 if($uname==$row[0] && $op==$row[1])
	 {
		$type=$row[2];
		$temp=1;
	 }
	}
	if($temp==1)
	{
	$sql = "UPDATE log_master SET Password='$np' WHERE Username='$uname' and Password='$op'";
	$result=mysqli_query($conn,$sql);
	if($type=='admin')
	{
	echo "<script>alert('password change successfully');location.href = 'home.php';</script>";
	}
	else
	{
		echo "<script>alert('password change successfully');location.href = 'home.php';</script>";
	}
	}
	else
	{
		echo "<script>alert('invalid username or password');
	location.href = 'changepassword.php';</script>";
	}
}
else
{
	echo "<script>alert('new password and confirm password are different');</script>";
}
}
?>