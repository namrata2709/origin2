from django.apps import AppConfig


class MentoringConfig(AppConfig):
    name = 'mentoring'
