from django.db import models
from userdetails.models import Student_detail,Teacher_detail
from subject.models import Subject
import os
def upload_location(instance,filename):
	return "%s/%s"%(instance.subject,filename)
# Create your models here.
class Docs(models.Model):
	Document_name=models.CharField(max_length=15)
	Document_description=models.CharField(max_length=15)
	teacher_id=models.ForeignKey(
						'userdetails.Teacher_detail',
						on_delete=models.SET_NULL,
						null=True
						)
	student_id=models.ForeignKey(
						'userdetails.Student_detail',
						on_delete=models.SET_NULL,
						null=True
						)
	subject=models.ForeignKey(
						'subject.Subject',
						models.CASCADE,null=True)
	document=models.FileField(upload_to=upload_location)
	approved=models.BooleanField(default=False)
	disapproved=models.BooleanField(default=False)
	def __str__(self):            
		return self.Document_name