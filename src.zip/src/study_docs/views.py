from django.shortcuts import render,redirect
from django.conf import settings
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.views.generic import CreateView,TemplateView,DeleteView
from django.urls import reverse_lazy

import os


from userdetails.models import Student_detail,Teacher_detail

from .forms import DocumentForm
from .models import Docs

# Create your views here.
class DocumentView(CreateView):
    form_class = DocumentForm
    success_url = '/'
    template_name ="form_add.html"
    def form_valid(self, form):
        Document = form.save(commit=False)
        if Teacher_detail.objects.filter(email_id=self.request.user ,subjects=Document.subject):
            Document.approved=True
            Document.teacher_id=Teacher_detail.objects.get(email_id=self.request.user)
        else :
        	Document.student_id=Student_detail.objects.get(email_id=self.request.user)
        Document.save()
        return super(DocumentView, self).form_valid(form)
class DocumentApproveView(TemplateView):
    template_name="DocumentApprove.html"
    def get_context_data(self,*args,**kwargs):
        if Teacher_detail.objects.filter(email_id=self.request.user):
            subjects=Teacher_detail.objects.filter(email_id=self.request.user).values('subjects__subject_name')
            for tag_searched in subjects:
                for value in tag_searched.values():
                    try:
                        object=object | Docs.objects.filter(subject__subject_name=value,approved=False)
                    except UnboundLocalError:
                        object=Docs.objects.filter(subject__subject_name=value,approved=False)
            context={"obj":object}
            return context
def DocumentApprove(request,id):
    obj=Docs.objects.get(pk=id) 
    obj.approved=True
    obj.teacher_id=Teacher_detail.objects.get(email_id=request.user)
    obj.save()
    return redirect('change_password')
def download(request, id):
    path=Docs.objects.get(pk=id) 
    obj=str(path.document)
    file_path = os.path.join(settings.MEDIA_ROOT, obj)
    if os.path.exists(file_path):
        #return  HttpResponse(path)
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/zip")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
            return response
    raise Http404
    return  HttpResponse(path)
def DocumentDisapprove(request,id):
    obj=Docs.objects.get(pk=id) 
    obj.disapproved=True
    obj.teacher_id=Teacher_detail.objects.get(email_id=request.user)
    obj.save()
    return redirect('change_password')
