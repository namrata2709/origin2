from django.apps import AppConfig


class StudyDocsConfig(AppConfig):
    name = 'study_docs'
