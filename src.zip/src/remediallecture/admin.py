from django.contrib import admin

# Register your models here.
from .models import RemedialLesson,RemedialCourse
admin.site.register(RemedialLesson)
admin.site.register(RemedialCourse)