from django import forms

from userdetails.models import Teacher_detail
from subject.models import Subject

from .models import RemedialCourse,RemedialLesson,CourseComment

from embed_video.fields import EmbedVideoFormField

class RemedialCoursesForm(forms.ModelForm):
	class Meta:
		model = RemedialCourse
		fields = ['title','description','subject','days']
	def __init__(self, user, *args, **kwargs):
	 	super(RemedialCoursesForm, self).__init__(*args, **kwargs)

	 	self.fields['subject'].queryset = Subject.objects.filter(subject_name__in=Teacher_detail.objects.filter(email_id=user).values('subjects__subject_name'))
class RemedialLessonsForm(forms.ModelForm):
	class Meta:
		model = RemedialLesson
		fields=['title','position','thumbnail','video']
		
class CourseCommentForm(forms.ModelForm):
	class Meta:
		model = CourseComment
		fields=['comment']
		widgets = {
			'comment':forms.Textarea(attrs={'cols':20, 'rows': 1,'placeholder':'Your comments...','id':"message",'class':"input100",'name':"message"},),
        }