from django.apps import AppConfig


class RemediallectureConfig(AppConfig):
    name = 'remediallecture'
