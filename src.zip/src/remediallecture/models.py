from django.db import models
from subject.models import Subject
from embed_video.fields import EmbedVideoField
from userdetails.models import Student_detail
# Create your models here.
def upload_location(instance):
	return "%s"%("RemedialLectures")
class RemedialLesson(models.Model):
	title=models.CharField(max_length=120)
	Course=models.ForeignKey(
        'RemedialCourse',
        on_delete=models.CASCADE,
        null=True
        )
	position=models.IntegerField()
	video=EmbedVideoField()
	thumbnail=models.ImageField(
					upload_to="upload_location",
					null=True,blank=True,
					width_field="width_field",
					height_field="height_field"
					)
	height_field=models.IntegerField(default=10)
	width_field=models.IntegerField(default=10)

class RemedialCourse(models.Model):
	title=models.CharField(max_length=120)
	description=models.CharField(max_length=250)
	user=models.ManyToManyField(Student_detail)
	subject=models.ForeignKey(
        'subject.Subject',
        on_delete=models.CASCADE,
        )
	days=models.IntegerField()
	@property
	def remediallessons(self):
		return self.remediallesson_set.all().order_by('position')
	@property
	def coursecomments(self):
		return self.coursecomment_set.all().order_by('-id')
	def __str__(self):
		return self.title

class CourseComment(models.Model):
	comment=models.CharField(max_length=150)
	Course=models.ForeignKey(
        'RemedialCourse',
        on_delete=models.CASCADE,
        null=True
        )
	user=models.ForeignKey(
        'userdetails.Student_detail',
        on_delete=models.CASCADE,
        null=True
        )