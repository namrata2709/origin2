from django.urls import path

from .views import (
					RemedialCourseDetailView,
					RemedialLessonDetailView,
					RemedialCourseListView,
					RemedialCourseAdd,
					RemedialCourseUpdate,
					RemedialCourseDelete,
					RemedialLessonAdd,
					RemedialLessonUpdate,
					RemedialLessonDelete,
					StudentRemedialCourse
					)

urlpatterns = [
   path('detail/<int:pk>',RemedialCourseDetailView.as_view(),name='RemedialCourseDetailView'),
   path('',RemedialCourseListView.as_view(),name='RemedialCourseListView'),
   path('add/',RemedialCourseAdd.as_view(),name='RemedialCourseAdd'),
   path('update/<int:pk>',RemedialCourseUpdate.as_view(),name='RemedialCourseUpdate'),
   path('delete/<int:pk>',RemedialCourseDelete.as_view(),name='RemedialCourseDelete'),
   path('lesson/<int:pk>',RemedialLessonDetailView.as_view(),name='RemedialLessonDetailView'),
   path('lesson/add/<int:pk>',RemedialLessonAdd.as_view(),name='RemedialLessonAdd'),
   path('lesson/update/<int:pk>',RemedialLessonUpdate.as_view(),name='RemedialLessonUpdate'),
   path('lesson/delete/<int:pk>',RemedialLessonDelete.as_view(),name='RemedialLessonDelete'),
   path('student/remedial/<int:course_id>/<int:lesson_id>',StudentRemedialCourse.as_view(),name='StudentRemedialCourse'),
]