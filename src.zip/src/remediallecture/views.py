from django.shortcuts import render
from .forms import RemedialCoursesForm,RemedialLessonsForm,CourseCommentForm
# Create your views here.
from django.views.generic import ListView,DetailView,View,CreateView,DeleteView,UpdateView
from django.urls import reverse_lazy
from .models import RemedialLesson,RemedialCourse,CourseComment
from userdetails.models import Student_detail
from subject.models import Subject
class RemedialCourseDetailView(DetailView):
	model=RemedialCourse
	template_name="Remedial_course_detail.html"

class RemedialLessonDetailView(DetailView):
	model=RemedialLesson
	template_name="Remedial_lesson_detail.html"

class RemedialCourseListView(ListView):
	model=RemedialCourse
	context_object_name = 'courses'
	template_name="Remedial_course_list.html"

class RemedialCourseAdd(CreateView):
    form_class = RemedialCoursesForm
    success_url = reverse_lazy('RemedialCourseListView')
    template_name ="Remedial_Course_form.html"
    def get_form_kwargs(self, **kwargs):
        kwargs = super(RemedialCourseAdd, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    

class RemedialLessonAdd(CreateView):
    form_class = RemedialLessonsForm
    success_url = reverse_lazy('RemedialCourseListView')
    template_name ="Remedial_Lesson_form.html"
    def get_context_data(self,**kwargs):
        kwargs=super(RemedialLessonAdd,self).get_context_data(**kwargs)
        kwargs['pk']=self.kwargs.get('pk')
        return kwargs
    def form_valid(self, form):
        lesson = form.save(commit=False)
        lesson.Course=RemedialCourse.objects.get(id=self.kwargs['pk'])
        lesson.save()
        return super(RemedialLessonAdd, self).form_valid(form)
        
class RemedialLessonUpdate(UpdateView):
    model =RemedialLesson
    template_name ="Remedial_Lesson_form.html"
    form_class = RemedialLessonsForm
    success_url = reverse_lazy('RemedialCourseDetailView')

class RemedialLessonDelete(DeleteView):
    model = RemedialLesson
    template_name ="Remedial_Lesson_confirm_delete.html"
    success_url = reverse_lazy('RemedialCourseListView')


class RemedialCourseUpdate(UpdateView):
    model =RemedialCourse
    template_name ="Remedial_Course_form.html"
    form_class = RemedialCoursesForm
    success_url = reverse_lazy('RemedialCourseListView')
    def get_form_kwargs(self, **kwargs):
        kwargs = super(RemedialCourseUpdate, self).get_form_kwargs()
        kwargs['user'] = self.request.user # pass the 'user' in kwargs
        return kwargs 
    
class RemedialCourseDelete(DeleteView):
    model = RemedialCourse
    template_name ="Remedial_Course_confirm_delete.html"
    success_url = reverse_lazy('RemedialCourseListView')

class StudentRemedialCourse(View):
    form_class = CourseCommentForm
    initial = {'key': 'value'}
    template_name = 'RemedialCourse.html'
    def get(self, request, *args, **kwargs):
        course=RemedialCourse.objects.get(id=kwargs['course_id'])
        lesson=course.remediallessons.get(id=kwargs['lesson_id'])
        form = self.form_class(initial=self.initial)
        return render(request, self.template_name, {'form': form , 'course' :course , 'lesson' : lesson })

    def post(self, request, *args, **kwargs):
        course=RemedialCourse.objects.get(id=kwargs['course_id'])
        lesson=course.remediallessons.get(id=kwargs['lesson_id'])
        form = self.form_class(request.POST)
        if form.is_valid():   
            comment=CourseComment.objects.create(comment=form.cleaned_data['comment'])
            comment.Course=course
            comment.user=Student_detail.objects.get(email_id=request.user)
            comment.save()
        return render(request, self.template_name, {'form': form, 'course' :course , 'lesson' : lesson })


