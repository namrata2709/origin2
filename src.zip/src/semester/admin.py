from django.contrib import admin
from .models import  Semester
# Register your models here.
admin.site.register(Semester)