from django.apps import AppConfig


class SemesterConfig(AppConfig):
    name = 'semester'
