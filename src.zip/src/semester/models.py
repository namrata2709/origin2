from django.db import models

# Create your models here.
class Semester(models.Model):
	semester 	=models.CharField(max_length=1)
	year		=models.CharField(max_length=1)
	def __str__(self):            
		return self.semester